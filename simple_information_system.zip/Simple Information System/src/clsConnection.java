
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.*;

public class clsConnection
{
     public static Connection conn;
    String url = "jdbc:odbc:konek";
    String driver = "sun.jdbc.odbc.JdbcOdbcDriver";

    public clsConnection(){
        try {
         Class.forName(driver);
         conn = DriverManager.getConnection(url);
        }catch (Exception e) {
        }
    }
}
